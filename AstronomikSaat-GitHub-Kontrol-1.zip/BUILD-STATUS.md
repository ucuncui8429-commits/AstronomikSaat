Derleme durumu: BU ORTAMDA DOĞRULANMADI. GitHub Actions üzerinde çalıştırılmalıdır.
Gradle Wrapper JAR ve scriptleri GitHub Actions içindeki gradle wrapper adımında oluşturulur.
APK yalnızca Build debug APK ve Verify debug APK adımları başarılıysa artifact olarak yüklenir.
