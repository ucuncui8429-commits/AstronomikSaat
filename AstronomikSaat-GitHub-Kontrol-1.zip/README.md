# Astronomik Saat — Android

## Derleme durumu
Bu paket **henüz derlenerek doğrulanmadı**. Bu çalışma ortamında Android SDK, Gradle ve internet erişimi bulunmadığından APK üretilemedi. GitHub Actions, JDK 17 / SDK 35 / Gradle 8.9 kullanarak APK derlemeyi dener.

## Önemli: Gradle Wrapper
`gradle/wrapper/gradle-wrapper.properties` pakettedir. Standart `gradlew`, `gradlew.bat` ve `gradle-wrapper.jar` dosyaları yerel ortamda üretilemedi. İş akışı `gradle wrapper --gradle-version 8.9` komutuyla bunları GitHub sunucusunda üretir ve `gradle-wrapper-generated` artifact olarak sunar. Böylece derleme adımı `bash ./gradlew :app:assembleDebug` ile çalışır. Wrapper dosyalarını kalıcı olarak depoya eklemek için artifact içeriğini daha sonra yükleyebilirsiniz.

## Telefonla GitHub üzerinden APK
1. Telefon tarayıcısında https://github.com/new sayfasından `AstronomikSaat` isimli **public veya private** depo oluşturun.
2. ZIP'i telefonun Dosyalar uygulamasında çıkartın. ZIP içindeki `AstronomikSaat` klasörünün **içeriğini** deponun köküne yükleyin. `.github/workflows/android-debug.yml` yolu korunmalıdır. GitHub mobil web arayüzü klasör yüklemeyi desteklemiyorsa masaüstü görünümünü veya GitHub'ın web editörünü kullanın.
3. Depoda **Actions** sekmesine, **Build Android Debug APK** iş akışına ve **Run workflow** düğmesine basın.
4. Çalışma kaydını açın. Yeşil onay alırsa sayfanın altındaki **Artifacts** bölümünden `AstronomikSaat-debug-apk` dosyasını indirin.
5. İndirilen artifact ZIP'ini çıkartın; içindeki `app-debug.apk` dosyasını açın. Android güvenlik uyarısı çıkarsa yalnızca kendi derlediğiniz APK'ya güvendiğiniz takdirde tarayıcı/dosya yöneticisine bu kurulum için izin verin.
6. Derleme kırmızı olursa **Build debug APK** adımının hata günlüğünü paylaşın. Başarılı APK henüz garanti edilmemektedir.

## Notlar
Harita gerçek kıta çizgilerini içermeyen temsili kutupsal ızgaradır. Güneş/Ay yörüngeleri ve gece-gündüz gölgesi temsildir. Hicri tarih cihazın `HijrahDate` hesaplamasına bağlıdır ve gözleme göre farklılık gösterebilir.
