package com.astronomiksaat.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.*
import java.time.chrono.HijrahDate
import java.time.temporal.ChronoField
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.*

private val gold = Color(0xFFEAC36A)
private val navy = Color(0xFF07152B)
private val tr = Locale("tr", "TR")
private val hijriMonths = listOf("Muharrem", "Safer", "Rebiülevvel", "Rebiülahir", "Cemaziyelevvel", "Cemaziyelahir", "Recep", "Şaban", "Ramazan", "Şevval", "Zilkade", "Zilhicce")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (4 or 1024 or 4096 or 512)
        window.navigationBarColor = android.graphics.Color.BLACK
        setContent { ClockScreen() }
    }
}

@Composable
private fun ClockScreen() {
    var now by remember { mutableStateOf(ZonedDateTime.now()) }
    LaunchedEffect(Unit) { while (true) { now = ZonedDateTime.now(); delay(1000L) } }
    val date = now.toLocalDate()
    val hijri = remember(date) { runCatching { HijrahDate.from(date) }.getOrNull() }
    val hDay = hijri?.get(ChronoField.DAY_OF_MONTH)
    val hMonth = hijri?.get(ChronoField.MONTH_OF_YEAR)
    val hYear = hijri?.get(ChronoField.YEAR)
    val lunarAge = moonAge(now.toInstant())
    val phase = when {
        lunarAge < 1.85 -> "Yeni Ay"
        lunarAge < 7.38 -> "Büyüyen Hilal"
        lunarAge < 9.22 -> "İlk Dördün"
        lunarAge < 14.77 -> "Büyüyen Şişkin Ay"
        lunarAge < 16.61 -> "Dolunay"
        lunarAge < 22.15 -> "Küçülen Şişkin Ay"
        lunarAge < 23.99 -> "Son Dördün"
        else -> "Küçülen Hilal"
    }
    val season = when(date.monthValue) { 12,1,2 -> "Kış"; 3,4,5 -> "İlkbahar"; 6,7,8 -> "Yaz"; else -> "Sonbahar" }
    Column(Modifier.fillMaxSize().background(Color.Black).padding(horizontal = 14.dp, vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceEvenly) {
        Text("ASTRONOMİK SAAT", color = gold, fontSize = 24.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Text(now.format(DateTimeFormatter.ofPattern("HH:mm:ss")), color = Color.White, fontSize = 43.sp, fontWeight = FontWeight.Light)
        Text(date.format(DateTimeFormatter.ofPattern("d MMMM yyyy EEEE", tr)), color = gold, fontSize = 15.sp)
        ClockMap(now, lunarAge, Modifier.fillMaxWidth().weight(1f).padding(vertical = 8.dp))
        Text("☀ Güneş: 24 saatlik temsili yörünge", color = gold, fontSize = 13.sp)
        Text("☾ Ay: ${"%.1f".format(Locale.US, lunarAge)} / 29,53 gün  •  $phase", color = Color.White, fontSize = 14.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Surface(color = navy, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("HİCRİ TAKVİM", color = gold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(if(hDay != null && hMonth != null && hYear != null) "$hDay ${hijriMonths[hMonth-1]} $hYear" else "Hicri tarih hesaplanamadı", color = Color.White, fontSize = 20.sp)
                Text("Mevsim: $season  •  Saat dilimi: ${now.zone.id}", color = gold, fontSize = 12.sp)
            }
        }
        Text("Harita, Güneş/Ay yörüngeleri ve aydınlanma temsildir. Hicri tarih hesaplaması gözleme göre 1–2 gün farklı olabilir.", color = Color.LightGray, fontSize = 10.sp, textAlign = TextAlign.Center)
    }
}

private fun moonAge(instant: Instant): Double {
    val reference = Instant.parse("2000-01-06T18:14:00Z")
    val days = (instant.epochSecond - reference.epochSecond) / 86400.0
    return ((days % 29.530588853) + 29.530588853) % 29.530588853
}

@Composable
private fun ClockMap(now: ZonedDateTime, age: Double, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val r = min(size.width, size.height) * 0.44f
        val c = Offset(size.width/2, size.height/2)
        drawCircle(navy, r, c)
        // Polar azimuthal grid: conceptual rings and meridians; no globe imagery.
        for (i in 1..4) drawCircle(gold.copy(alpha=.24f), r*i/4f, c, style=Stroke(1.dp.toPx()))
        for (i in 0 until 24) {
            val a = i*PI/12 - PI/2
            drawLine(gold.copy(alpha=.26f), c, Offset(c.x+(r*cos(a)).toFloat(), c.y+(r*sin(a)).toFloat()), 1.dp.toPx())
        }
        val fraction = (now.hour*3600+now.minute*60+now.second)/86400.0
        val angle = fraction*2*PI-PI/2
        val seasonal = cos(2*PI*(now.dayOfYear-172)/365.2422)
        val sunRadius = r * (0.57f + 0.23f * seasonal.toFloat())
        val sun = Offset(c.x+sunRadius*cos(angle).toFloat(), c.y+sunRadius*sin(angle).toFloat())
        // Schematic moving night hemisphere, not a physical solar illumination calculation.
        val shadow = Path().apply { moveTo(c.x,c.y); arcTo(androidx.compose.ui.geometry.Rect(c.x-r,c.y-r,c.x+r,c.y+r), (fraction*360+90).toFloat(),180f,false); close() }
        drawPath(shadow, Color.Black.copy(alpha=.48f))
        drawCircle(gold.copy(alpha=.35f), sunRadius, c, style=Stroke(1.5.dp.toPx()))
        drawCircle(gold, 12.dp.toPx(), sun)
        val moonAngle = angle + age/29.530588853*2*PI
        val mr = r*.91f
        val moon = Offset(c.x+mr*cos(moonAngle).toFloat(),c.y+mr*sin(moonAngle).toFloat())
        drawCircle(Color(0xFFD9E2F2), 8.dp.toPx(), moon)
        drawCircle(Color(0xFF536078).copy(alpha=.8f), 6.dp.toPx(), Offset(moon.x+(4*cos(age/29.530588853*2*PI)).toFloat(),moon.y))
        val paint = android.graphics.Paint().apply { color=android.graphics.Color.rgb(234,195,106); textAlign=android.graphics.Paint.Align.CENTER; textSize=12.sp.toPx(); isAntiAlias=true }
        drawContext.canvas.nativeCanvas.drawText("KUZEY",c.x,c.y-r-9.dp.toPx(),paint)
        drawContext.canvas.nativeCanvas.drawText("90° K",c.x,c.y+5.dp.toPx(),paint)
    }
}
